import Sidenav from "./Sidenav";
function App() {
  return <>
  <Sidenav/>
  </>;
}

export default App;
